"""PCB component placement algorithms."""

from .bbox import BoundingBox

__all__ = [
    "BoundingBox",
]