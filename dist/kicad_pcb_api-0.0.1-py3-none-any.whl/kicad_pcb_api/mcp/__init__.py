"""MCP server interface for kicad-pcb-api."""

from .server import create_server, main

__all__ = [
    "create_server",
    "main",
]